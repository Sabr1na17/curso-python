#coding:utf-8

#Cores usadas
CorBranco = "#feffff"
CorRoxa = '#cca2eb'
CorLaranja = "#ffab40"
CorCinzaClaro = "#c9c7c9"
CorCinzaEscuro = "#6e6d6e"
